
var http = require('http'),
    url = require('url');

var procesador = function(request, response) {
	var urlParseada = url.parse(request.url, true);
	
	if (urlParseada.pathname == '/registrar') {
		if (request.method == 'GET') {
			response.writeHead(200, { 
				'Content-Type' : 'text/html'
			});			
			response.write('<p>Instancia ' + 
                           urlParseada.query.instancia + 
						   ' registrada</p>');
		} else {
			response.writeHead(405);
		}
	} else {
		response.writeHead(404);
	}
	response.end();
}

var server = http.createServer(procesador);
server.listen(80);