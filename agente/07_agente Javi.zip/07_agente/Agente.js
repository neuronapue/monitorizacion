console.log('Iniciando módulo agente.');

var os = require('os');

var Estadistica = function () {
	var fecha = new Date();
	this.timestamp = fecha.getTime();
	this.memoriaLibre = os.freemem();
	this.tiempoCPU = this._obtenerTiempoCPU();
	this.tiempoCPUIdle = this._obtenerTiempoCPUIdle();
};

Estadistica.prototype._obtenerTiempoCPU = function() {
	var segundosTotales = 0;
	var datosCpus = os.cpus();
	for (var i=0; i < datosCpus.length; i++) {
		var cpuActual = datosCpus[i];
		segundosTotales = segundosTotales +
			cpuActual.times.idle +
			cpuActual.times.user +
			cpuActual.times.nice +
			cpuActual.times.sys +
			cpuActual.times.irq; 
	}
	return segundosTotales;
};

Estadistica.prototype._obtenerTiempoCPUIdle = function() {
	var segundosTotales = 0;
	var datosCpus = os.cpus();
	for (var i=0; i < datosCpus.length; i++) {
		var cpuActual = datosCpus[i];
		segundosTotales = segundosTotales +
			cpuActual.times.idle; 
	}
	return segundosTotales;
};

var Agente = function(id) {
	this.id = id;
	this.memoriaTotal = os.totalmem();
	this.datosEstadisticos = [];
	console.info('Objeto Agente inicializado con el id ' + id + '.');
}

Agente.prototype._agregarEstadistica = function() {
	var estadisticaActual = new Estadistica();
	this.datosEstadisticos.push(estadisticaActual);
	console.log('Nueva estadística registrada: ' 
	           +JSON.stringify(estadisticaActual));
	if (this.datosEstadisticos.length > 60) {
		console.log('Excesivas estadísticas almacenadas, '
		           +' borrando la más antigua.');
		this.datosEstadisticos.shift();
	}
};


Agente.prototype.activar = function() {	
	var self = this;
	console.info('Agente ' + this.id + ' activado.');
	setInterval(function() {
		self._agregarEstadistica();
		var cpu = self.obtenerUsoCPUMedioUltimoMinuto();
		var mensaje = (cpu == undefined) ? 'No disponible.' : parseInt(cpu*100) + '%';
		console.log('Uso medio CPU último minuto: ' + mensaje);
	}, 1000);
}

Agente.prototype.obtenerUsoCPUMedioUltimoMinuto = function() {
	if (this.datosEstadisticos.length < 60) {
		return;
	}
	var sumaCPU = 0;
	for (var i=1; i < this.datosEstadisticos.length; i++) {
		var tiempoCPUSegundoActual =
			this.datosEstadisticos[i].tiempoCPU - this.datosEstadisticos[i-1].tiempoCPU;
		var tiempoCPUIdleSegundoActual =
			this.datosEstadisticos[i].tiempoCPUIdle - this.datosEstadisticos[i-1].tiempoCPUIdle;
		var usoMedioSegundoActual = 1.0 - (tiempoCPUIdleSegundoActual / tiempoCPUSegundoActual);
		sumaCPU = sumaCPU + usoMedioSegundoActual;
	}
	
	var media = sumaCPU / this.datosEstadisticos.length;
	return media;
};

if (process.argv.length < 3) {
	console.warn('Número de argumentos insuficiente.');
} else {
	var nombreAgente = process.argv[2];
	var agente = new Agente(nombreAgente);
	agente.activar();
}













